// Simple C program to display "Hello World"

// Includes
#include <stdio.h>
  
// Main function
int main(void) {

    // Prints hello world
    printf("Hello World!\n");
  
    return 0;
} // end main