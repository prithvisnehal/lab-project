To do:
- Add more documentation/comments!
- Get git terminal to close automatically on start (use expect?)
- Get new line after code run
- Check git credentials
